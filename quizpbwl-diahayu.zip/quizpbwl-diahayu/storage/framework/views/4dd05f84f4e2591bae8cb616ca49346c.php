
<?php $__env->startSection('content'); ?>

<h2>Pelanggan</h2>

<a href="<?php echo e(route('pel_create')); ?>" class="btn btn-primary mb-3 float-end"> Add Pelanggan</a>


<table class="table table-bordered">
    <tr>
        <th>NO</th>
        <th>GOLONGAN</th>
        <th>NO PELANGGAN</th>
        <th>NAMA</th>
        <th>ALAMAT</th>
        <th>NO HP</th>
        <th>KTP</th>
        <th>SERI</th>
        <th>METERAN</th>
        <th>AKTIF</th>
        <th>USER</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr> 

    <?php
        $counter = 1; // Inisialisasi variabel counter
    ?>

    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($counter++); ?></td>
            <td><?php echo e($row->golongan->gol_nama); ?></td>
            <td><?php echo e($row->pel_no); ?></td>
            <td><?php echo e($row->pel_nama); ?></td>
            <td><?php echo e($row->pel_alamat); ?></td>
            <td><?php echo e($row->pel_hp); ?></td>
            <td><?php echo e($row->pel_ktp); ?></td>
            <td><?php echo e($row->pel_seri); ?></td>
            <td><?php echo e($row->pel_meteran); ?></td>
            <td><?php echo e($row->pel_aktif); ?></td>
            <td><?php echo e($row->user->name); ?></td>
            <td><a href="<?php echo e(url('pelanggan/edit/' . $row->id)); ?>" class="btn btn-warning">Edit</a></td>
            <td>
                <form action="<?php echo e(route('pel_delete', ['id' => $row->id])); ?>" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">Delete
                    </button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\quizdiva-pbwl\resources\views/pelanggan/index.blade.php ENDPATH**/ ?>